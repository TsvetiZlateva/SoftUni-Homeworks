﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ferrari
{
    public interface ICar
    {
        public string Brakes();

        public string Gas();
       
    }
}

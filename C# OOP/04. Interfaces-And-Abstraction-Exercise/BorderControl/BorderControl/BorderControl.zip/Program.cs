﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> ids = new List<string>();
            string input = Console.ReadLine();

            while (input != "End")
            {
                var tokens = input.Split(" ");

                if (tokens.Length == 3)
                {
                    Citizen citizen = new Citizen(tokens[0], int.Parse(tokens[1]), tokens[2]);
                    ids.Add(citizen.Id);
                }

                if (tokens.Length == 2)
                {
                    Robot robot = new Robot(tokens[0], tokens[1]);
                    ids.Add(robot.Id);
                }

                input = Console.ReadLine();
            }

            string fakeId = Console.ReadLine();

            foreach (var id in ids)
            {
                if (id.Contains(fakeId) && id.IndexOf(fakeId) == id.Length - fakeId.Length)
                {
                    Console.WriteLine(id);
                }
            }
        }
    }
}

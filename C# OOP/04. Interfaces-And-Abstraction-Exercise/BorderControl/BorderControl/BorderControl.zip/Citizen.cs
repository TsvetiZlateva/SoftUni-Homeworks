﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public class Citizen: ILicence
    {
        public Citizen(string name, int age, string id)
        {
            this.Age = age;
            this.Name = name;
            this.Id = id;
        }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Id { get; set; }
    }
}

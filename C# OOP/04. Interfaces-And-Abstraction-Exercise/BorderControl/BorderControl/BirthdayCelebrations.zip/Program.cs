﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> birthdates = new List<string>();
            string input = Console.ReadLine();

            while (input != "End")
            {
                var tokens = input.Split(" ");

                if (tokens[0] == "Citizen")
                {
                    Citizen citizen = new Citizen(tokens[1], int.Parse(tokens[2]), tokens[3], tokens[4]);
                    birthdates.Add(citizen.Birthdate);
                }

                if (tokens[0] == "Pet")
                {
                    Pet pet = new Pet(tokens[1], tokens[2]);
                    birthdates.Add(pet.Birthdate);
                }

                input = Console.ReadLine();
            }

            string year = Console.ReadLine();

            foreach (var bd in birthdates)
            {
                if (bd.Contains(year) && bd.IndexOf(year) == bd.Length - year.Length)
                {
                    Console.WriteLine(bd);
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface ILicence
    {
        public string Id { get; set; }
    }
}
